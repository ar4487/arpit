﻿using sprint2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using sprint2.ViewModel;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Authorization;

namespace sprint2.Controllers
{
    [Route("api/[controller]")]
    [EnableCors("AllowOrigin")]
    [ApiController]


    public class LoginController : ControllerBase
    {
        CommonContext db;
        private IConfiguration config;
        public LoginController(CommonContext _db, IConfiguration _Config)
        {
            db = _db;
            config = _Config;
        }
        [AllowAnonymous]
        [HttpPost("Authenticate")]
        public IActionResult Authenticate(LoginViewModel loginViewModel)
        {
            string AdminUsername = "Admin";
            string AdminPassword = "Admin12345678";
            string Email = "A@gmail.com";
            string id = "1";

            var islogin = db.Signups.FirstOrDefault(x => x.UserName == loginViewModel.UserName && x.Password.Equals(loginViewModel.Password));
            var AdminLogin = AdminUsername == loginViewModel.UserName && AdminPassword == loginViewModel.Password;
             

            
           
            // return Ok(new { IsLogin = islogin, Token = token, Message = islogin ? "Successfully login" : "Either username or password is incorrect" });
            if (islogin!=null)
            {
                return Ok(new JwtManagerRespository(config).GenerateToken(
                    islogin.ID.ToString(),
                    islogin.UserName,
                    islogin.Email
                    )
                    );
            }
            else if (AdminLogin == true)
            {
                return Ok("Admin login " + new JwtManagerRespository(config).GenerateToken(
                 id,
                 AdminUsername,
                 Email
                  
                   )
                   );
            }
            return Ok("Either username or password is incorrect");
        }

        
    }
}