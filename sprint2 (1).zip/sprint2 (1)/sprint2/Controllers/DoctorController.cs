﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using sprint2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sprint2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class DoctorController : ControllerBase
    {
        CommonContext db;
        public DoctorController(CommonContext _db)
        {
            db = _db;
        }
        [HttpGet]
        public IEnumerable<Doctor> get()
        {
            return db.Doctors;
        }
        [HttpPost("Doctor")]
        public IActionResult Doctor(Doctor doctor)
        {
            db.Doctors.Add(doctor);
            db.SaveChanges();
            return Ok("success");
        }
        [HttpDelete("Delete")]
        public IActionResult Delete(int id)
        {
            var delete = db.Doctors.FirstOrDefault(x => x.Id == id);
            var isdelete = db.Doctors.Any(x => x.Id == id);
            if (isdelete) {
                db.Doctors.Remove(delete);
                db.SaveChanges();
                return Ok("Successfully deleted");
            }
            return Ok("Data not existed");
        }
        [HttpPut("UpdateDoctor")]
        public IActionResult UpdateDoctor(int id, Doctor doctor)
        {
            var UpdateDoctor = db.Doctors.FirstOrDefault(x => x.Id == id);
            var isupdate = db.Doctors.Any(x => x.Id == id);
            if (isupdate) {

                UpdateDoctor.Name = doctor.Name;
                UpdateDoctor.Specialization = doctor.Specialization;
                UpdateDoctor.About = doctor.About;
                UpdateDoctor.Availability = doctor.Availability;


                db.Doctors.Update(UpdateDoctor);
                db.SaveChanges();
                return Ok("Successfully");
            }
            return Ok("Data not exist");
                }
    }
}
